//
//  OneLoginPro+NoUI.h
//  OneLoginSDK
//
//  Created by noctis on 2021/7/16.
//  Copyright © 2021 geetest. All rights reserved.
//

#import <OneLoginSDK/OneLoginSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface OneLoginPro ()

+ (void)requestTokenWithCompletion:(void(^)(NSDictionary * _Nullable result))completion;

@end

NS_ASSUME_NONNULL_END
