//
//  OLButton.h
//  OneLoginSDK
//
//  Created by noctis on 2019/8/2.
//  Copyright © 2019 geetest. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OLButton : UIButton

@end

NS_ASSUME_NONNULL_END
