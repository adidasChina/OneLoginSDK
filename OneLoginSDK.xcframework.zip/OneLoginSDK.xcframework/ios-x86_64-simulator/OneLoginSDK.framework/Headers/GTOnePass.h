//
//  GTOnePass.h
//  GTOnePass
//
//  Created by NikoXu on 24/09/2017.
//  Copyright © 2017 geetest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GTOnePass.
FOUNDATION_EXPORT double GTOnePassVersionNumber;

//! Project version string for GTOnePass.
FOUNDATION_EXPORT const unsigned char GTOnePassVersionString[];

#import <OneLoginSDK/GOPManager.h>


