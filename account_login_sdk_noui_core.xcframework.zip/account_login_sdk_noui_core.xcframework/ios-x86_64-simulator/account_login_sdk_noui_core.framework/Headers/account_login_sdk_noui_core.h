//
//  account_login_sdk_noui_core.h
//  account_login_sdk_noui_core
//
//  Created by zhuof on 2018/9/25.
//  Copyright © 2018年 xiaowo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for account_login_sdk_noui_core.
FOUNDATION_EXPORT double account_login_sdk_noui_coreVersionNumber;

//! Project version string for account_login_sdk_noui_core.
FOUNDATION_EXPORT const unsigned char account_login_sdk_noui_coreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <account_login_sdk_noui_core/PublicHeader.h>

//#import <account_login_sdk_noui_core/UniAuthHelper.h>
#import "UniAuthHelper.h"

